self.port.on('loading_complete', function() {
  XKit.init();
});
